<?php

$Episode_1 = array(
	"Episode_Title" => "The Pineapple Incident",
	"Episode_Info" 	=> "Ted asks his friends what happened and finds out his wild night included falling off a table while singing karaoke, being set on fire by Barney (Neil Patrick Harris), and drunk dialing Robin (Cobie Smulders) multiple times. From the information he gathers, he thinks the woman in his bed is Robin, but it’s actually a girl named Trudy who he met at the bar. Ted took the shots to stop overthinking, but it ended up making things more complicated.",
	"Episode_SE"	=> "Season 1, Episode 10",
	"Episode_Thumb" => "img/1.jpg"
	);
$Episode_2 =array(
	"Episode_Title" => "Come On",
	"Episode_Info" 	=> "Not one to give up easily, Ted tries to win over Robin, but she’s hesitant to start a relationship with him. He attempts to do a rain dance, hoping that a storm would cause the trip to get cancelled. Even though this is a dumb idea, it actually does rain and Robin decides she wants to be with Ted.",
	"Episode_SE"	=> "Season 1, Episode 22",
	"Episode_Thumb" => "img/2.jpg"
	);
$Episode_3 =array(
	"Episode_Title" => "Swarley",
	"Episode_Info" 	=> "This episode gets its title from Barney’s misspelled name on a coffee cup. This random little thing becomes a joke throughout the episode, as the gang continually refers to Barney as Swarley and he gets more and more upset.",
	"Episode_SE"	=> "Season 2, Episode 7",
	"Episode_Thumb" => "img/3.jpg"
	);
$Episode_4 =array(
	"Episode_Title" => "Something Borrowed",
	"Episode_Info" 	=> "It’s Marshall and Lily’s wedding day and everything is going wrong. Lily’s ex-boyfriend shows up in an effort to win her back, a groomsman tackles the photographer, and the harp player is in labor. To make matters worse, Marshall unwittingly gets frosted tips in his hair and shaves his head in a moment of panic.",
	"Episode_SE"	=> "Season 2, Episode 21",
	"Episode_Thumb" => "img/4.jpg"
	);
$Episode_5 =array(
	"Episode_Title" => "Slapsgiving",
	"Episode_Info" 	=> "Lily and Marshall are hosting their first Thanksgiving. Lily is preparing dinner, but Marshall is getting ready to deliver the third slap of his slap bet with Barney. He mercilessly taunts Barney and even creates a website with a timer counting down to the moment of the slap.",
	"Episode_SE"	=> "Season 3, Episode 9",
	"Episode_Thumb" => "img/5.jpg"
	);
$Episode_6 =array(
	"Episode_Title" => "Three Days Of Snow",
	"Episode_Info" 	=> "At MacLaren’s, the bartender leaves Ted and Barney in charge of the empty bar while they wait for their dates. However, their dates are members of a marching band, and they bring the whole band along with them.",
	"Episode_SE"	=> "Season 4, Episode 13",
	"Episode_Thumb" => "img/6.jpg"
	);


$Episode_7 =array(
	"Episode_Title" => "Girls Versus Suits",
	"Episode_Info" 	=> "Meanwhile, Barney is facing a difficult choice. He has his eye on the new hot bartender at MacLaren’s, but she despises men who wear suits. She gives him an ultimatum: her or his suits. Barney launches into a giant musical number about how he would never give up his precious suits for a woman. But despite claiming “nothing suits me like a suit,” he changes his mind and hooks up with her anyway.",
	"Episode_SE"	=> "Season 5, Episode 12",
	"Episode_Thumb" => "img/7.jpg"
	);
$Episode_8 =array(
	"Episode_Title" => "Last Words",
	"Episode_Info" 	=> "The show does a great job of balancing humor with more poignant moments. One of the most emotionally resonant episodes takes place at the funeral for Marshall’s father, after he passed away suddenly in the previous episode. The gang accompanies Marshall to Minnesota for the service, but they aren’t sure how to cheer him up.",
	"Episode_SE"	=> "Season 6, Episode 14",
	"Episode_Thumb" => "img/8.jpg"
	);
$Episode_9 =array(
	"Episode_Title" => "Your Mother Met Me",
	"Episode_Info" 	=> "In the show’s ninth season, we are finally introduced to the Mother, whose real name is Tracy. She turns out to be extremely likeable and charming, living up to the high expectations set for the character. The 200th episode of the series shines a light on her side of the story, revisiting scenes from past episodes to show her near misses with Ted throughout the years.",
	"Episode_SE"	=> "Season 9, Episode 16",
	"Episode_Thumb" => "img/9.jpg"
	);
$Episode_10 =array(
	"Episode_Title" => "Honorable Mentions",
	"Episode_Info" 	=> "We learn about Barney's past life as a hippie, and how he became a suit-wearing lothario.",
	"Episode_SE"	=> "Season 1, Episode 15",
	"Episode_Thumb" => "img/10.jpg"
	);








?>